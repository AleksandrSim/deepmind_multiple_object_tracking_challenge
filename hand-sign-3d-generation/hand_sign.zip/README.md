# Hand Sign 3D Generation


## Repo structure

* `scripts` - Small, stand alone scripts and entrypoints to run train and other similar tasks.
* `src` - The main project code location.
* `configs` - The configuration files for the project.
* `notebooks` - Jupyter notebooks.
* `tests` - Test code with pytest.


